//
//  CalculatorViewController.swift
//  Pourboire
//
//  Created by Frédéric Gicquiaud on 24/09/2016.
//  Copyright © 2016 Frédéric Gicquiaud. All rights reserved.
//

import UIKit

class CalculatorViewController: UIViewController {

    @IBOutlet weak var additionLabel: UILabel!
    @IBOutlet weak var pourboireLabel: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var tauxLabel: UILabel!
    @IBOutlet weak var sliderTaux: UISlider!
 
    
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        updateDisplay()
    }
    
    @IBAction func sliderTauxValueChanged(_ sender: UISlider) {
        updateDisplay()
    }
    

    
    
    func updateDisplay() {
        let tauxPourboire = sliderTaux.value / 100
        let montantAddition = slider.value
        let montantPourboire = Double(montantAddition) * Double(tauxPourboire)
        additionLabel.text = String(Int(montantAddition))+" "+"$"
        pourboireLabel.text = String(Int(montantPourboire))+" "+"$"
        tauxLabel.text = String(Int(tauxPourboire*100))
        
    }
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        updateDisplay()
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
