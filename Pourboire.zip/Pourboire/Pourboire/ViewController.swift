//
//  ViewController.swift
//  Pourboire
//
//  Created by Frédéric Gicquiaud on 24/09/2016.
//  Copyright © 2016 Frédéric Gicquiaud. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var messageLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        messageLabel.text = "Pourboire US"
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

